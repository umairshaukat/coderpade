class Config{
    static loginUrl="http://127.0.0.1:8000/api/gettoken/";
    static registerUrl="pass the register url here bro";
    static homeUrl="/home";
   }
   
   export default Config;